package com.example.qola.repository;

import com.example.qola.model.Score;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ScoreRepository extends JpaRepository<Score, Long> {

    @Query(value = "SELECT 'eh' AS label, AVG(s.eh) AS averageScore FROM Score s " +
            "UNION ALL " +
            "SELECT 'ph' AS label, AVG(s.ph) AS averageScore FROM Score s " +
            "UNION ALL " +
            "SELECT 'mh' AS label, AVG(s.mh) AS averageScore FROM Score s " +
            "UNION ALL " +
            "SELECT 'sh' AS label, AVG(s.sh) AS averageScore FROM Score s " +
            "UNION ALL " +
            "SELECT 'total' AS label, AVG(s.total) AS averageScore FROM Score s", nativeQuery = true)
    Object[][] calculateAverageScores();

    List<Score> findByEmail(String email);

    @Query(value = "SELECT COALESCE(teacher.gender, student.gender) AS gender, " +
            "AVG(score.eh) AS averageEh, " +
            "AVG(score.ph) AS averagePh, " +
            "AVG(score.mh) AS averageMh, " +
            "AVG(score.sh) AS averageSh, " +
            "AVG(score.total) AS averageTotal " +
            "FROM Score score " +
            "LEFT JOIN Teacher teacher ON score.email = teacher.email " +
            "LEFT JOIN Student student ON score.email = student.email " +
            "GROUP BY COALESCE(teacher.gender, student.gender)", nativeQuery = true)
    List<Object[]> calculateGenderWiseAverageScores();

    @Query(value = "SELECT type, " +
            "AVG(eh) AS averageEh, " +
            "AVG(ph) AS averagePh, " +
            "AVG(mh) AS averageMh, " +
            "AVG(sh) AS averageSh, " +
            "AVG(total) AS averageTotal " +
            "FROM Score " +
            "GROUP BY type", nativeQuery = true)
    List<Object[]> calculateTypeWiseAverageScores();

    @Query(value = "SELECT " +
            "    CASE " +
            "        WHEN COALESCE(t.age, s.age) < 20 THEN '<20' " +
            "        WHEN COALESCE(t.age, s.age) BETWEEN 20 AND 29 THEN '20-29' " +
            "        WHEN COALESCE(t.age, s.age) BETWEEN 30 AND 39 THEN '30-39' " +
            "        WHEN COALESCE(t.age, s.age) BETWEEN 40 AND 49 THEN '40-49' " +
            "        WHEN COALESCE(t.age, s.age) BETWEEN 50 AND 59 THEN '50-59' " +
            "        ELSE '>=60' " +
            "    END AS age_group, " +
            "    AVG(score.eh) AS average_eh, " +
            "    AVG(score.ph) AS average_ph, " +
            "    AVG(score.mh) AS average_mh, " +
            "    AVG(score.sh) AS average_sh, " +
            "    AVG(score.total) AS average_total " +
            "FROM score " +
            "LEFT JOIN teacher t ON score.email = t.email " +
            "LEFT JOIN student s ON score.email = s.email " +
            "GROUP BY age_group", nativeQuery = true)
    List<Object[]> calculateAgeGroupWiseAverageScores();
    @Query(value = "SELECT " +
            "    AVG(eh) AS average_eh, " +
            "    AVG(ph) AS average_ph, " +
            "    AVG(mh) AS average_mh, " +
            "    AVG(sh) AS average_sh, " +
            "    AVG(total) AS average_total " +
            "FROM " +
            "    score " +
            "WHERE " +
            "    type = 'teacher'", nativeQuery = true)
    List<Object[]> calculateTeacherAverageScores();

    @Query(value = "SELECT " +
            "    COALESCE(t.gender, 'Unknown') AS gender, " +
            "    AVG(score.eh) AS average_eh, " +
            "    AVG(score.ph) AS average_ph, " +
            "    AVG(score.mh) AS average_mh, " +
            "    AVG(score.sh) AS average_sh, " +
            "    AVG(score.total) AS average_total " +
            "FROM score " +
            "LEFT JOIN teacher t ON score.email = t.email " +
            "WHERE score.type = 'teacher' " +
            "GROUP BY COALESCE(t.gender, 'Unknown')", nativeQuery = true)
    List<Object[]> calculateTeacherAverageScoreByGender();

    @Query(value = "SELECT " +
            "    COALESCE(t.university_role, 'Unknown') AS university_role, " +
            "    AVG(score.eh) AS average_eh, " +
            "    AVG(score.ph) AS average_ph, " +
            "    AVG(score.mh) AS average_mh, " +
            "    AVG(score.sh) AS average_sh, " +
            "    AVG(score.total) AS average_total " +
            "FROM score " +
            "LEFT JOIN teacher t ON score.email = t.email " +
            "WHERE score.type = 'teacher' " +
            "GROUP BY COALESCE(t.university_role, 'Unknown')", nativeQuery = true)
    List<Object[]> calculateTeacherAverageScoreByUniversityRole();

    @Query(value = "SELECT " +
            "    CASE " +
            "        WHEN t.age < 20 THEN '<20' " +
            "        WHEN t.age BETWEEN 20 AND 29 THEN '20-29' " +
            "        WHEN t.age BETWEEN 30 AND 39 THEN '30-39' " +
            "        WHEN t.age BETWEEN 40 AND 49 THEN '40-49' " +
            "        WHEN t.age BETWEEN 50 AND 59 THEN '50-59' " +
            "        ELSE '>=60' " +
            "    END AS age_group, " +
            "    AVG(score.eh) AS average_eh, " +
            "    AVG(score.ph) AS average_ph, " +
            "    AVG(score.mh) AS average_mh, " +
            "    AVG(score.sh) AS average_sh, " +
            "    AVG(score.total) AS average_total " +
            "FROM score " +
            "LEFT JOIN teacher t ON score.email = t.email " +
            "WHERE score.type = 'teacher' " +
            "GROUP BY age_group", nativeQuery = true)
    List<Object[]> calculateTeacherAverageScoresByAgeGroup();

    @Query(value = "SELECT " +
            "    AVG(s.eh) AS averageEh, " +
            "    AVG(s.ph) AS averagePh, " +
            "    AVG(s.mh) AS averageMh, " +
            "    AVG(s.sh) AS averageSh, " +
            "    AVG(s.total) AS averageTotal " +
            "FROM " +
            "    Score s " +
            "INNER JOIN " +
            "    Teacher t ON s.email = t.email " +
            "WHERE " +
            "    t.university_role = 'teaching'",nativeQuery = true)
    List<Object[]> findAverageScoresForTeachingUniversityRole();

    @Query(value = "SELECT " + // Note the space after SELECT
            "    t.gender, " + // Note the space after gender
            "    AVG(s.eh) AS average_eh, " + // Note the space after average_eh
            "    AVG(s.ph) AS average_ph, " + // Note the space after average_ph
            "    AVG(s.mh) AS average_mh, " + // Note the space after average_mh
            "    AVG(s.sh) AS average_sh, " + // Note the space after average_sh
            "    AVG(s.total) AS average_total " + // Note the space after average_total
            "FROM " + // Note the space after FROM
            "    score s " + // Note the space after score s
            "INNER JOIN " + // Note the space after INNER JOIN
            "    teacher t ON s.email = t.email " + // Note the space after t.email
            "WHERE " + // Note the space after WHERE
            "    t.university_role = 'teaching' " + // Note the space after 'teaching'
            "GROUP BY " + // Note the space after GROUP BY
            "    t.gender", nativeQuery = true)
    List<Object[]> calculateAverageScoreTeachingGenderWise();

    @Query(value = "SELECT " +
            "    t.designation, " +
            "    AVG(s.eh) AS average_eh, " +
            "    AVG(s.ph) AS average_ph, " +
            "    AVG(s.mh) AS average_mh, " +
            "    AVG(s.sh) AS average_sh, " +
            "    AVG(s.total) AS average_total " +
            "FROM " +
            "    score s " +
            "INNER JOIN " +
            "    teacher t ON s.email = t.email " +
            "WHERE " +
            "    t.university_role = 'teaching' " +
            "GROUP BY " +
            "    t.designation ", nativeQuery = true)
    List<Object[]> calculateAverageScoreTeachingDesignationWise();
    @Query(value = "SELECT " +
            "    CASE " +
            "        WHEN t.age < 20 THEN '<20' " +
            "        WHEN t.age BETWEEN 20 AND 29 THEN '20-29' " +
            "        WHEN t.age BETWEEN 30 AND 39 THEN '30-39' " +
            "        WHEN t.age BETWEEN 40 AND 49 THEN '40-49' " +
            "        WHEN t.age BETWEEN 50 AND 59 THEN '50-59' " +
            "        ELSE '>=60' " +
            "    END AS age_group, " +
            "    AVG(s.eh) AS average_eh, " +
            "    AVG(s.ph) AS average_ph, " +
            "    AVG(s.mh) AS average_mh, " +
            "    AVG(s.sh) AS average_sh, " +
            "    AVG(s.total) AS average_total " +
            "FROM " +
            "    Score s " +
            "INNER JOIN " +
            "    Teacher t ON s.email = t.email " +
            "WHERE " +
            "    t.university_role='teaching' " +
            "GROUP BY " +
            "    age_group", nativeQuery = true)
    List<Object[]> calculateAverageScoresByTeachingAgeGroup();


    // non-teaching wise
    @Query(value = "SELECT " +
            "    AVG(s.eh) AS averageEh, " +
            "    AVG(s.ph) AS averagePh, " +
            "    AVG(s.mh) AS averageMh, " +
            "    AVG(s.sh) AS averageSh, " +
            "    AVG(s.total) AS averageTotal " +
            "FROM " +
            "    Score s " +
            "INNER JOIN " +
            "    Teacher t ON s.email = t.email " +
            "WHERE " +
            "    t.university_role = 'nonteaching'",nativeQuery = true)
    List<Object[]> findAverageScoresForNonTeachingUniversityRole();

    @Query(value = "SELECT " + // Note the space after SELECT
            "    t.gender, " + // Note the space after gender
            "    AVG(s.eh) AS average_eh, " + // Note the space after average_eh
            "    AVG(s.ph) AS average_ph, " + // Note the space after average_ph
            "    AVG(s.mh) AS average_mh, " + // Note the space after average_mh
            "    AVG(s.sh) AS average_sh, " + // Note the space after average_sh
            "    AVG(s.total) AS average_total " + // Note the space after average_total
            "FROM " + // Note the space after FROM
            "    score s " + // Note the space after score s
            "INNER JOIN " + // Note the space after INNER JOIN
            "    teacher t ON s.email = t.email " + // Note the space after t.email
            "WHERE " + // Note the space after WHERE
            "    t.university_role = 'nonteaching' " + // Note the space after 'teaching'
            "GROUP BY " + // Note the space after GROUP BY
            "    t.gender", nativeQuery = true)
    List<Object[]> calculateAverageScoreNonTeachingGenderWise();

    @Query(value = "SELECT " +
            "    t.designation, " +
            "    AVG(s.eh) AS average_eh, " +
            "    AVG(s.ph) AS average_ph, " +
            "    AVG(s.mh) AS average_mh, " +
            "    AVG(s.sh) AS average_sh, " +
            "    AVG(s.total) AS average_total " +
            "FROM " +
            "    score s " +
            "INNER JOIN " +
            "    teacher t ON s.email = t.email " +
            "WHERE " +
            "    t.university_role = 'nonteaching' " +
            "GROUP BY " +
            "    t.designation ", nativeQuery = true)
    List<Object[]> calculateAverageScoreNonTeachingDesignationWise();
    @Query(value = "SELECT " +
            "    CASE " +
            "        WHEN t.age < 20 THEN '<20' " +
            "        WHEN t.age BETWEEN 20 AND 29 THEN '20-29' " +
            "        WHEN t.age BETWEEN 30 AND 39 THEN '30-39' " +
            "        WHEN t.age BETWEEN 40 AND 49 THEN '40-49' " +
            "        WHEN t.age BETWEEN 50 AND 59 THEN '50-59' " +
            "        ELSE '>=60' " +
            "    END AS age_group, " +
            "    AVG(s.eh) AS average_eh, " +
            "    AVG(s.ph) AS average_ph, " +
            "    AVG(s.mh) AS average_mh, " +
            "    AVG(s.sh) AS average_sh, " +
            "    AVG(s.total) AS average_total " +
            "FROM " +
            "    Score s " +
            "INNER JOIN " +
            "    Teacher t ON s.email = t.email " +
            "WHERE " +
            "    t.university_role='nonteaching' " +
            "GROUP BY " +
            "    age_group", nativeQuery = true)
    List<Object[]> calculateAverageScoresByNonTeachingAgeGroup();


    //office-staff
    @Query(value = "SELECT " +
            "    AVG(s.eh) AS averageEh, " +
            "    AVG(s.ph) AS averagePh, " +
            "    AVG(s.mh) AS averageMh, " +
            "    AVG(s.sh) AS averageSh, " +
            "    AVG(s.total) AS averageTotal " +
            "FROM " +
            "    Score s " +
            "INNER JOIN " +
            "    Teacher t ON s.email = t.email " +
            "WHERE " +
            "    t.university_role = 'officestaff'",nativeQuery = true)
    List<Object[]> findAverageScoresForOfficeStaffUniversityRole();

    @Query(value = "SELECT " + // Note the space after SELECT
            "    t.gender, " + // Note the space after gender
            "    AVG(s.eh) AS average_eh, " + // Note the space after average_eh
            "    AVG(s.ph) AS average_ph, " + // Note the space after average_ph
            "    AVG(s.mh) AS average_mh, " + // Note the space after average_mh
            "    AVG(s.sh) AS average_sh, " + // Note the space after average_sh
            "    AVG(s.total) AS average_total " + // Note the space after average_total
            "FROM " + // Note the space after FROM
            "    score s " + // Note the space after score s
            "INNER JOIN " + // Note the space after INNER JOIN
            "    teacher t ON s.email = t.email " + // Note the space after t.email
            "WHERE " + // Note the space after WHERE
            "    t.university_role = 'officestaff' " + // Note the space after 'teaching'
            "GROUP BY " + // Note the space after GROUP BY
            "    t.gender", nativeQuery = true)
    List<Object[]> calculateAverageScoreOfficeStaffGenderWise();

    @Query(value = "SELECT " +
            "    CASE " +
            "        WHEN t.age < 20 THEN '<20' " +
            "        WHEN t.age BETWEEN 20 AND 29 THEN '20-29' " +
            "        WHEN t.age BETWEEN 30 AND 39 THEN '30-39' " +
            "        WHEN t.age BETWEEN 40 AND 49 THEN '40-49' " +
            "        WHEN t.age BETWEEN 50 AND 59 THEN '50-59' " +
            "        ELSE '>=60' " +
            "    END AS age_group, " +
            "    AVG(s.eh) AS average_eh, " +
            "    AVG(s.ph) AS average_ph, " +
            "    AVG(s.mh) AS average_mh, " +
            "    AVG(s.sh) AS average_sh, " +
            "    AVG(s.total) AS average_total " +
            "FROM " +
            "    Score s " +
            "INNER JOIN " +
            "    Teacher t ON s.email = t.email " +
            "WHERE " +
            "    t.university_role='officestaff' " +
            "GROUP BY " +
            "    age_group", nativeQuery = true)
    List<Object[]> calculateAverageScoresByOfficeStaffAgeGroup();

    //student
    @Query(value = "SELECT " +
            "    AVG(eh) AS average_eh, " +
            "    AVG(ph) AS average_ph, " +
            "    AVG(mh) AS average_mh, " +
            "    AVG(sh) AS average_sh, " +
            "    AVG(total) AS average_total " +
            "FROM " +
            "    score " +
            "WHERE " +
            "    type = 'student'", nativeQuery = true)
    List<Object[]> calculateStudentAverageScores();

    @Query(value = "SELECT " +
            "COALESCE(st.gender, 'Unknown') AS gender, " +
            "AVG(score.eh) AS average_eh, " +
            "AVG(score.ph) AS average_ph, " +
            "AVG(score.mh) AS average_mh, " +
            "AVG(score.sh) AS average_sh, " +
            "AVG(score.total) AS average_total " +
            "FROM score " +
            "LEFT JOIN student st ON score.email = st.email " +
            "WHERE score.type = 'student' " +
            "GROUP BY COALESCE(st.gender, 'Unknown')", nativeQuery = true)
    List<Object[]> calculateStudentAverageScoreByGender();

    @Query(value = "SELECT " +
            "COALESCE(st.status, 'Unknown') AS gender, " +
            "AVG(score.eh) AS average_eh, " +
            "AVG(score.ph) AS average_ph, " +
            "AVG(score.mh) AS average_mh, " +
            "AVG(score.sh) AS average_sh, " +
            "AVG(score.total) AS average_total " +
            "FROM score " +
            "LEFT JOIN student st ON score.email = st.email " +
            "WHERE score.type = 'student' " +
            "GROUP BY COALESCE(st.status, 'Unknown')", nativeQuery = true)
    List<Object[]> calculateStudentAverageScoreByStatus();

    @Query(value = "SELECT " +
            "COALESCE(st.semester, 'Unknown') AS gender, " +
            "AVG(score.eh) AS average_eh, " +
            "AVG(score.ph) AS average_ph, " +
            "AVG(score.mh) AS average_mh, " +
            "AVG(score.sh) AS average_sh, " +
            "AVG(score.total) AS average_total " +
            "FROM score " +
            "LEFT JOIN student st ON score.email = st.email " +
            "WHERE score.type = 'student' " +
            "GROUP BY COALESCE(st.semester, 'Unknown')", nativeQuery = true)
    List<Object[]> calculateStudentAverageScoreBySemester();

    //post-graduate
    @Query(value = "SELECT " +
            "    AVG(s.eh) AS averageEh, " +
            "    AVG(s.ph) AS averagePh, " +
            "    AVG(s.mh) AS averageMh, " +
            "    AVG(s.sh) AS averageSh, " +
            "    AVG(s.total) AS averageTotal " +
            "FROM " +
            "    Score s " +
            "INNER JOIN " +
            "    student t ON s.email = t.email " +
            "WHERE " +
            "    t.status = 'postgraduate'",nativeQuery = true)
    List<Object[]> findAverageScoresForPostGraduateStatus();

    @Query(value = "SELECT " + // Note the space after SELECT
            "    t.gender, " + // Note the space after gender
            "    AVG(s.eh) AS average_eh, " + // Note the space after average_eh
            "    AVG(s.ph) AS average_ph, " + // Note the space after average_ph
            "    AVG(s.mh) AS average_mh, " + // Note the space after average_mh
            "    AVG(s.sh) AS average_sh, " + // Note the space after average_sh
            "    AVG(s.total) AS average_total " + // Note the space after average_total
            "FROM " + // Note the space after FROM
            "    score s " + // Note the space after score s
            "INNER JOIN " + // Note the space after INNER JOIN
            "    student t ON s.email = t.email " + // Note the space after t.email
            "WHERE " + // Note the space after WHERE
            "    t.status = 'postgraduate' " + // Note the space after 'teaching'
            "GROUP BY " + // Note the space after GROUP BY
            "    t.gender", nativeQuery = true)
    List<Object[]> calculateAverageScorePostGraduateGenderWise();

    @Query(value = "SELECT " +
            "    t.degree, " + // corrected from t.designation to t.degree
            "    AVG(s.eh) AS average_eh, " +
            "    AVG(s.ph) AS average_ph, " +
            "    AVG(s.mh) AS average_mh, " +
            "    AVG(s.sh) AS average_sh, " +
            "    AVG(s.total) AS average_total " +
            "FROM " +
            "    score s " +
            "INNER JOIN " +
            "    student t ON s.email = t.email " +
            "WHERE " +
            "    t.status = 'postgraduate' " +
            "GROUP BY " +
            "    t.degree", nativeQuery = true)
    List<Object[]> calculateAverageScorePostGraduateDegreeWise();


    @Query(value = "SELECT " +
            "    t.semester, " + // corrected from t.designation to t.semester
            "    AVG(s.eh) AS average_eh, " +
            "    AVG(s.ph) AS average_ph, " +
            "    AVG(s.mh) AS average_mh, " +
            "    AVG(s.sh) AS average_sh, " +
            "    AVG(s.total) AS average_total " +
            "FROM " +
            "    score s " +
            "INNER JOIN " +
            "    student t ON s.email = t.email " +
            "WHERE " +
            "    t.status = 'postgraduate' " +
            "GROUP BY " +
            "    t.semester", nativeQuery = true)
    List<Object[]> calculateAverageScorePostGraduateSemesterWise();

    //undergraduate
    @Query(value = "SELECT " +
            "    AVG(s.eh) AS averageEh, " +
            "    AVG(s.ph) AS averagePh, " +
            "    AVG(s.mh) AS averageMh, " +
            "    AVG(s.sh) AS averageSh, " +
            "    AVG(s.total) AS averageTotal " +
            "FROM " +
            "    Score s " +
            "INNER JOIN " +
            "    student t ON s.email = t.email " +
            "WHERE " +
            "    t.status = 'undergraduate'",nativeQuery = true)
    List<Object[]> findAverageScoresForUnderGraduateStatus();

    @Query(value = "SELECT " + // Note the space after SELECT
            "    t.gender, " + // Note the space after gender
            "    AVG(s.eh) AS average_eh, " + // Note the space after average_eh
            "    AVG(s.ph) AS average_ph, " + // Note the space after average_ph
            "    AVG(s.mh) AS average_mh, " + // Note the space after average_mh
            "    AVG(s.sh) AS average_sh, " + // Note the space after average_sh
            "    AVG(s.total) AS average_total " + // Note the space after average_total
            "FROM " + // Note the space after FROM
            "    score s " + // Note the space after score s
            "INNER JOIN " + // Note the space after INNER JOIN
            "    student t ON s.email = t.email " + // Note the space after t.email
            "WHERE " + // Note the space after WHERE
            "    t.status = 'undergraduate' " + // Note the space after 'teaching'
            "GROUP BY " + // Note the space after GROUP BY
            "    t.gender", nativeQuery = true)
    List<Object[]> calculateAverageScoreUnderGraduateGenderWise();

    @Query(value = "SELECT " +
            "    t.degree, " + // corrected from t.designation to t.degree
            "    AVG(s.eh) AS average_eh, " +
            "    AVG(s.ph) AS average_ph, " +
            "    AVG(s.mh) AS average_mh, " +
            "    AVG(s.sh) AS average_sh, " +
            "    AVG(s.total) AS average_total " +
            "FROM " +
            "    score s " +
            "INNER JOIN " +
            "    student t ON s.email = t.email " +
            "WHERE " +
            "    t.status = 'undergraduate' " +
            "GROUP BY " +
            "    t.degree", nativeQuery = true)
    List<Object[]> calculateAverageScoreUnderGraduateDegreeWise();


    @Query(value = "SELECT " +
            "    t.semester, " + // corrected from t.designation to t.semester
            "    AVG(s.eh) AS average_eh, " +
            "    AVG(s.ph) AS average_ph, " +
            "    AVG(s.mh) AS average_mh, " +
            "    AVG(s.sh) AS average_sh, " +
            "    AVG(s.total) AS average_total " +
            "FROM " +
            "    score s " +
            "INNER JOIN " +
            "    student t ON s.email = t.email " +
            "WHERE " +
            "    t.status = 'undergraduate' " +
            "GROUP BY " +
            "    t.semester", nativeQuery = true)
    List<Object[]> calculateAverageScoreUnderGraduateSemesterWise();

    @Query(value = "SELECT s.email, s.eh, s.ph, s.mh, s.sh, s.total, s.time FROM score s WHERE s.email = :email ORDER BY s.time DESC LIMIT 1", nativeQuery = true)
    List<Object[]> findRecentScoreByEmail(@Param("email") String email);

}
