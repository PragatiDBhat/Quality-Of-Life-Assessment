package com.example.qola.controller;

import com.example.qola.model.Student;
import com.example.qola.model.Teacher;
import com.example.qola.repository.TeacherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
public class TeacherController {
    @Autowired
    private TeacherRepository teacherRepository;

    @PostMapping("/teacher/register")
    public ResponseEntity<String> newTeacher(@RequestBody Teacher newTeacher)
    {
        Optional<Teacher> existingUser = teacherRepository.findByEmail(newTeacher.getEmail());
        if (existingUser.isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("User already exists");
        }
        teacherRepository.save(newTeacher);
        return ResponseEntity.status(HttpStatus.CREATED).body("User created successfully");
    }
    @PostMapping("/teacher/login")
    public ResponseEntity<String> login(@RequestBody Teacher loginTeacher) {
        Optional<Teacher> existingUser = teacherRepository.findByEmail(loginTeacher.getEmail());
        if (existingUser.isPresent()) {
            if (existingUser.get().getPassword().equals(loginTeacher.getPassword())) {
                return ResponseEntity.ok("Login successful");
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Incorrect password");
            }
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
        }
    }
    @GetMapping("/teacher/displayteacher")
    public ResponseEntity<?> getTeacherByEmail(@RequestParam String email) {
        Optional<Teacher> teacher = teacherRepository.findByEmail(email);
        if (teacher.isPresent()) {
            return ResponseEntity.ok(teacher.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Teacher not found");
        }
    }

    @PutMapping("/teacher/update")
    public ResponseEntity<String> updateTeacher(@RequestBody Teacher updatedTeacher) {
        Optional<Teacher> existingTeacher = teacherRepository.findByEmail(updatedTeacher.getEmail());
        if (existingTeacher.isPresent()) {
            Teacher teacher = existingTeacher.get();
            teacher.setName(updatedTeacher.getName());
            teacher.setEmp_id(updatedTeacher.getEmp_id());
            teacher.setPassword(updatedTeacher.getPassword());
            teacher.setDob(updatedTeacher.getDob());
            teacher.setAge(updatedTeacher.getAge());
            teacher.setQualification(updatedTeacher.getQualification());
            teacher.setExperience(updatedTeacher.getExperience());
            teacher.setUniversity_role(updatedTeacher.getUniversity_role());
            teacher.setDesignation(updatedTeacher.getDesignation());
            teacher.setGender(updatedTeacher.getGender());
            teacherRepository.save(teacher);
            return ResponseEntity.ok("Teacher information updated successfully");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Teacher not found");
        }
    }
}

