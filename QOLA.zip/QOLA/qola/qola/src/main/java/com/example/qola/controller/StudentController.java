package com.example.qola.controller;

import com.example.qola.model.Student;
import com.example.qola.model.User;
import com.example.qola.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
public class StudentController {
    @Autowired
    private StudentRepository studentRepository;

    @PostMapping("/student/register")
    public ResponseEntity<String> newStudent(@RequestBody Student newStudent)
    {
        Optional<Student> existingUser = studentRepository.findByEmail(newStudent.getEmail());
        if (existingUser.isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("User already exists");
        }
        studentRepository.save(newStudent);
        return ResponseEntity.status(HttpStatus.CREATED).body("User created successfully");
    }

    @PostMapping("/student/login")
    public ResponseEntity<String> login(@RequestBody Student loginStudent) {
        Optional<Student> existingUser = studentRepository.findByEmail(loginStudent.getEmail());
        if (existingUser.isPresent()) {
            if (existingUser.get().getPassword().equals(loginStudent.getPassword())) {
                return ResponseEntity.ok("Login successful");
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Incorrect password");
            }
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
        }
    }
    @GetMapping("/student/displaystudent")
    public ResponseEntity<?> getStudentByEmail(@RequestParam String email) {
        Optional<Student> student = studentRepository.findByEmail(email);
        if (student.isPresent()) {
            return ResponseEntity.ok(student.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Student not found");
        }
    }
    @PutMapping("/student/update")
    public ResponseEntity<String> updateStudent(@RequestBody Student updatedStudent) {
        Optional<Student> existingStudent = studentRepository.findByEmail(updatedStudent.getEmail());
        if (existingStudent.isPresent()) {
            Student student = existingStudent.get();
            student.setName(updatedStudent.getName());
            student.setUsn(updatedStudent.getUsn());
            student.setPassword(updatedStudent.getPassword());
            student.setDob(updatedStudent.getDob());
            student.setAge(updatedStudent.getAge());
            student.setStatus(updatedStudent.getStatus());
            student.setDegree(updatedStudent.getDegree());
            student.setSemester(updatedStudent.getSemester());
            student.setGender(updatedStudent.getGender());
            studentRepository.save(student);
            return ResponseEntity.ok("Student information updated successfully");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Student not found");
        }
    }
}
