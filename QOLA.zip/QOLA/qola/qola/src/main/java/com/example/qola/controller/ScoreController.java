package com.example.qola.controller;

import com.example.qola.model.Score;
import com.example.qola.repository.ScoreRepository;
import com.example.qola.repository.TeacherRepository;
import com.example.qola.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class ScoreController {

    @Autowired
    private ScoreRepository scoreRepository;

    @Autowired
    private TeacherRepository teacherRepository;

    @Autowired
    private StudentRepository studentRepository;

    @PostMapping("/score")
    public ResponseEntity<String> saveScore(@RequestBody Score score) {
        // Check if the email exists in either teacher or student table based on the type
        boolean exists = false;
        if ("teacher".equals(score.getType())) {
            exists = teacherRepository.existsByEmail(score.getEmail());
        } else if ("student".equals(score.getType())) {
            exists = studentRepository.existsByEmail(score.getEmail());
        }

        if (exists) {
            scoreRepository.save(score);
            return ResponseEntity.status(HttpStatus.CREATED).body("Score saved successfully");
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Email not found in teacher or student table");
        }
    }

    @GetMapping("/scoredisplay")
    public ResponseEntity<?> getScoresByEmail(@RequestParam String email) {
        List<Score> scores = scoreRepository.findByEmail(email);
        if (!scores.isEmpty()) {
            return ResponseEntity.ok(scores);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No scores found for the given email");
        }
    }

    // Inner class to hold average scores response
    @GetMapping("/average-scores")
    public ResponseEntity<?> getAverageScores() {
        Object[][] averageScores = scoreRepository.calculateAverageScores();

        // Check if the result is not null
        if (averageScores != null) {
            // Create a map to hold the labels and average scores
            Map<String, Double> averageScoresMap = new HashMap<>();
            for (Object[] row : averageScores) {
                // Extract label and average score from each row
                String label = (String) row[0];
                Double averageScore = (Double) row[1];
                // Add label and average score to the map
                averageScoresMap.put(label, averageScore);
            }
            return ResponseEntity.ok(averageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving average scores");
        }
    }

    @GetMapping("/gender-wise-average-scores")
    public ResponseEntity<?> getGenderWiseAverageScores() {
        List<Object[]> genderWiseAverageScores = scoreRepository.calculateGenderWiseAverageScores();

        // Check if the result is not null
        if (genderWiseAverageScores != null) {
            // Create a map to hold the gender-wise average scores
            Map<String, Map<String, Double>> genderWiseAverageScoresMap = new HashMap<>();
            for (Object[] row : genderWiseAverageScores) {
                // Extract gender and average scores from each row
                String gender = (String) row[0];
                Double averageEh = (Double) row[1];
                Double averagePh = (Double) row[2];
                Double averageMh = (Double) row[3];
                Double averageSh = (Double) row[4];
                Double averageTotal = (Double) row[5];

                // Create a map to hold the average scores for each gender
                Map<String, Double> averageScoresMap = new HashMap<>();
                averageScoresMap.put("averageEh", averageEh);
                averageScoresMap.put("averagePh", averagePh);
                averageScoresMap.put("averageMh", averageMh);
                averageScoresMap.put("averageSh", averageSh);
                averageScoresMap.put("averageTotal", averageTotal);

                // Add gender and its corresponding average scores to the map
                genderWiseAverageScoresMap.put(gender, averageScoresMap);
            }
            return ResponseEntity.ok(genderWiseAverageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving gender-wise average scores");
        }
    }

    @GetMapping("/type-wise-average-scores")
    public ResponseEntity<?> getTypeWiseAverageScores() {
        List<Object[]> typeWiseAverageScores = scoreRepository.calculateTypeWiseAverageScores();

        // Check if the result is not null
        if (typeWiseAverageScores != null) {
            // Create a map to hold the type-wise average scores
            Map<String, Map<String, Double>> typeWiseAverageScoresMap = new HashMap<>();
            for (Object[] row : typeWiseAverageScores) {
                // Extract type, labels, and average scores from each row
                String type = (String) row[0];
                Double averageEh = (Double) row[1];
                Double averagePh = (Double) row[2];
                Double averageMh = (Double) row[3];
                Double averageSh = (Double) row[4];
                Double averageTotal = (Double) row[5];

                // Create a map to hold the average scores for each type
                Map<String, Double> averageScoresMap = new HashMap<>();
                averageScoresMap.put("averageEh", averageEh);
                averageScoresMap.put("averagePh", averagePh);
                averageScoresMap.put("averageMh", averageMh);
                averageScoresMap.put("averageSh", averageSh);
                averageScoresMap.put("averageTotal", averageTotal);

                // Add type and its corresponding average scores to the map
                typeWiseAverageScoresMap.put(type, averageScoresMap);
            }
            return ResponseEntity.ok(typeWiseAverageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving type-wise average scores");
        }
    }

    @GetMapping("/age-group-wise-average-scores")
    public ResponseEntity<?> getAgeGroupWiseAverageScores() {
        List<Object[]> ageGroupWiseAverageScores = scoreRepository.calculateAgeGroupWiseAverageScores();

        // Check if the result is not null
        if (ageGroupWiseAverageScores != null) {
            // Create a map to hold the age group-wise average scores
            Map<String, Map<String, Double>> ageGroupWiseAverageScoresMap = new HashMap<>();
            for (Object[] row : ageGroupWiseAverageScores) {
                // Extract age group, labels, and average scores from each row
                String ageGroup = (String) row[0];
                Double averageEh = (Double) row[1];
                Double averagePh = (Double) row[2];
                Double averageMh = (Double) row[3];
                Double averageSh = (Double) row[4];
                Double averageTotal = (Double) row[5];

                // Create a map to hold the average scores for each age group
                Map<String, Double> averageScoresMap = new HashMap<>();
                averageScoresMap.put("averageEh", averageEh);
                averageScoresMap.put("averagePh", averagePh);
                averageScoresMap.put("averageMh", averageMh);
                averageScoresMap.put("averageSh", averageSh);
                averageScoresMap.put("averageTotal", averageTotal);

                // Add age group and its corresponding average scores to the map
                ageGroupWiseAverageScoresMap.put(ageGroup, averageScoresMap);
            }
            return ResponseEntity.ok(ageGroupWiseAverageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving age group-wise average scores");
        }
    }

    @GetMapping("/average-teacher-scores")
    public ResponseEntity<?> getAverageTeacherScores() {
        List<Object[]> teacherAverageScores = scoreRepository.calculateTeacherAverageScores();

        // Check if the result is not null
        if (teacherAverageScores != null && !teacherAverageScores.isEmpty()) {
            Double averageEh = (Double) teacherAverageScores.get(0)[0];
            Double averagePh = (Double) teacherAverageScores.get(0)[1];
            Double averageMh = (Double) teacherAverageScores.get(0)[2];
            Double averageSh = (Double) teacherAverageScores.get(0)[3];
            Double averageTotal = (Double) teacherAverageScores.get(0)[4];

            // Create a map to hold the average scores for teachers
            Map<String, Double> averageScoresMap = new HashMap<>();
            averageScoresMap.put("averageEh", averageEh);
            averageScoresMap.put("averagePh", averagePh);
            averageScoresMap.put("averageMh", averageMh);
            averageScoresMap.put("averageSh", averageSh);
            averageScoresMap.put("averageTotal", averageTotal);

            return ResponseEntity.ok(averageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving average teacher scores");
        }
    }
    @GetMapping("/teacher-gender-wise-average-scores")
    public ResponseEntity<?> getTeacherGenderWiseAverageScores() {
        List<Object[]> genderWiseAverageScores = scoreRepository.calculateTeacherAverageScoreByGender();

        // Check if the result is not null
        if (genderWiseAverageScores != null) {
            // Create a map to hold the gender-wise average scores
            Map<String, Map<String, Double>> genderWiseAverageScoresMap = new HashMap<>();
            for (Object[] row : genderWiseAverageScores) {
                // Extract gender and average scores from each row
                String gender = (String) row[0];
                Double averageEh = (Double) row[1];
                Double averagePh = (Double) row[2];
                Double averageMh = (Double) row[3];
                Double averageSh = (Double) row[4];
                Double averageTotal = (Double) row[5];

                // Create a map to hold the average scores for each gender
                Map<String, Double> averageScoresMap = new HashMap<>();
                averageScoresMap.put("averageEh", averageEh);
                averageScoresMap.put("averagePh", averagePh);
                averageScoresMap.put("averageMh", averageMh);
                averageScoresMap.put("averageSh", averageSh);
                averageScoresMap.put("averageTotal", averageTotal);

                // Add gender and its corresponding average scores to the map
                genderWiseAverageScoresMap.put(gender, averageScoresMap);
            }
            return ResponseEntity.ok(genderWiseAverageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving gender-wise average scores");
        }
    }
    @GetMapping("/teacher-university-role-wise-average-scores")
    public ResponseEntity<?> getTeacherUniversityRoleWiseAverageScores() {
        List<Object[]> universityRoleWiseAverageScores = scoreRepository.calculateTeacherAverageScoreByUniversityRole();

        // Check if the result is not null
        if (universityRoleWiseAverageScores != null) {
            // Create a map to hold the university role-wise average scores
            Map<String, Map<String, Double>> universityRoleWiseAverageScoresMap = new HashMap<>();
            for (Object[] row : universityRoleWiseAverageScores) {
                // Extract university role and average scores from each row
                String universityRole = (String) row[0];
                Double averageEh = (Double) row[1];
                Double averagePh = (Double) row[2];
                Double averageMh = (Double) row[3];
                Double averageSh = (Double) row[4];
                Double averageTotal = (Double) row[5];

                // Create a map to hold the average scores for each university role
                Map<String, Double> averageScoresMap = new HashMap<>();
                averageScoresMap.put("averageEh", averageEh);
                averageScoresMap.put("averagePh", averagePh);
                averageScoresMap.put("averageMh", averageMh);
                averageScoresMap.put("averageSh", averageSh);
                averageScoresMap.put("averageTotal", averageTotal);

                // Add university role and its corresponding average scores to the map
                universityRoleWiseAverageScoresMap.put(universityRole, averageScoresMap);
            }
            return ResponseEntity.ok(universityRoleWiseAverageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving university role-wise average scores");
        }
    }

    @GetMapping("/teacher-average-scores-by-age-group")
    public ResponseEntity<?> getTeacherAverageScoresByAgeGroup() {
        List<Object[]> teacherAverageScoresByAgeGroup = scoreRepository.calculateTeacherAverageScoresByAgeGroup();

        if (teacherAverageScoresByAgeGroup != null) {
            Map<String, Map<String, Double>> averageScoresMap = new HashMap<>();

            for (Object[] row : teacherAverageScoresByAgeGroup) {
                String ageGroup = (String) row[0];
                Double averageEh = (Double) row[1];
                Double averagePh = (Double) row[2];
                Double averageMh = (Double) row[3];
                Double averageSh = (Double) row[4];
                Double averageTotal = (Double) row[5];

                Map<String, Double> scores = new HashMap<>();
                scores.put("averageEh", averageEh);
                scores.put("averagePh", averagePh);
                scores.put("averageMh", averageMh);
                scores.put("averageSh", averageSh);
                scores.put("averageTotal", averageTotal);

                averageScoresMap.put(ageGroup, scores);
            }

            return ResponseEntity.ok(averageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error retrieving teacher average scores by age group");
        }
    }
    @GetMapping("/average-scores-teaching")
    public ResponseEntity<?> getAverageScoresForTeachingUniversityRole() {
        List<Object[]> averageScores = scoreRepository.findAverageScoresForTeachingUniversityRole();

        if (averageScores != null && !averageScores.isEmpty()) {
            Object[] firstRow = averageScores.get(0);
            Map<String, Double> averageScoresMap = new HashMap<>();
            averageScoresMap.put("averageEh", (Double) firstRow[0]);
            averageScoresMap.put("averagePh", (Double) firstRow[1]);
            averageScoresMap.put("averageMh", (Double) firstRow[2]);
            averageScoresMap.put("averageSh", (Double) firstRow[3]);
            averageScoresMap.put("averageTotal", (Double) firstRow[4]);

            return ResponseEntity.ok(averageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving average scores for teaching university role");
        }
    }
    @GetMapping("/average-scores-teaching-gender-wise")
    public ResponseEntity<?> getAverageScoresForTeachingUniversityRoleGenderWise() {
        List<Object[]>genderWiseAverageScores = scoreRepository.calculateAverageScoreTeachingGenderWise();

        if (genderWiseAverageScores != null) {
            // Create a map to hold the gender-wise average scores
            Map<String, Map<String, Double>> genderWiseAverageScoresMap = new HashMap<>();
            for (Object[] row : genderWiseAverageScores) {
                // Extract gender and average scores from each row
                String designtion = (String) row[0];
                Double averageEh = (Double) row[1];
                Double averagePh = (Double) row[2];
                Double averageMh = (Double) row[3];
                Double averageSh = (Double) row[4];
                Double averageTotal = (Double) row[5];

                // Create a map to hold the average scores for each gender
                Map<String, Double> averageScoresMap = new HashMap<>();
                averageScoresMap.put("averageEh", averageEh);
                averageScoresMap.put("averagePh", averagePh);
                averageScoresMap.put("averageMh", averageMh);
                averageScoresMap.put("averageSh", averageSh);
                averageScoresMap.put("averageTotal", averageTotal);

                // Add gender and its corresponding average scores to the map
                genderWiseAverageScoresMap.put(designtion, averageScoresMap);
            }
            return ResponseEntity.ok(genderWiseAverageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving gender-wise average scores");
        }
    }
    @GetMapping("/average-scores-teaching-designation-wise")
    public ResponseEntity<?> getAverageScoresForTeachingUniversityRoleDesignationWise() {
        List<Object[]>genderWiseAverageScores = scoreRepository.calculateAverageScoreTeachingDesignationWise();

        if (genderWiseAverageScores != null) {
            // Create a map to hold the gender-wise average scores
            Map<String, Map<String, Double>> genderWiseAverageScoresMap = new HashMap<>();
            for (Object[] row : genderWiseAverageScores) {
                // Extract gender and average scores from each row
                String gender = (String) row[0];
                Double averageEh = (Double) row[1];
                Double averagePh = (Double) row[2];
                Double averageMh = (Double) row[3];
                Double averageSh = (Double) row[4];
                Double averageTotal = (Double) row[5];

                // Create a map to hold the average scores for each gender
                Map<String, Double> averageScoresMap = new HashMap<>();
                averageScoresMap.put("averageEh", averageEh);
                averageScoresMap.put("averagePh", averagePh);
                averageScoresMap.put("averageMh", averageMh);
                averageScoresMap.put("averageSh", averageSh);
                averageScoresMap.put("averageTotal", averageTotal);

                // Add gender and its corresponding average scores to the map
                genderWiseAverageScoresMap.put(gender, averageScoresMap);
            }
            return ResponseEntity.ok(genderWiseAverageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving gender-wise average scores");
        }
    }

    @GetMapping("/average-scores-teaching-age-group")
    public ResponseEntity<?> getAverageScoresByTeachingAgeGroup() {
        List<Object[]> averageScores = scoreRepository.calculateAverageScoresByTeachingAgeGroup();

        if (averageScores != null && !averageScores.isEmpty()) {
            Map<String, Map<String, Double>> ageGroupAverageScoresMap = new HashMap<>();
            for (Object[] row : averageScores) {
                String ageGroup = (String) row[0];
                Map<String, Double> averageScoresMap = new HashMap<>();
                averageScoresMap.put("averageEh", (Double) row[1]);
                averageScoresMap.put("averagePh", (Double) row[2]);
                averageScoresMap.put("averageMh", (Double) row[3]);
                averageScoresMap.put("averageSh", (Double) row[4]);
                averageScoresMap.put("averageTotal", (Double) row[5]);
                ageGroupAverageScoresMap.put(ageGroup, averageScoresMap);
            }
            return ResponseEntity.ok(ageGroupAverageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error retrieving average scores by age group");
        }
    }

    //non-teaching

    @GetMapping("/average-scores-non-teaching")
    public ResponseEntity<?> getAverageScoresForNonTeachingUniversityRole() {
        List<Object[]> averageScores = scoreRepository.findAverageScoresForNonTeachingUniversityRole();

        if (averageScores != null && !averageScores.isEmpty()) {
            Object[] firstRow = averageScores.get(0);
            Map<String, Double> averageScoresMap = new HashMap<>();
            averageScoresMap.put("averageEh", (Double) firstRow[0]);
            averageScoresMap.put("averagePh", (Double) firstRow[1]);
            averageScoresMap.put("averageMh", (Double) firstRow[2]);
            averageScoresMap.put("averageSh", (Double) firstRow[3]);
            averageScoresMap.put("averageTotal", (Double) firstRow[4]);

            return ResponseEntity.ok(averageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving average scores for teaching university role");
        }
    }
    @GetMapping("/average-scores-non-teaching-gender-wise")
    public ResponseEntity<?> getAverageScoresForNonTeachingUniversityRoleGenderWise() {
        List<Object[]>genderWiseAverageScores = scoreRepository.calculateAverageScoreNonTeachingGenderWise();

        if (genderWiseAverageScores != null) {
            // Create a map to hold the gender-wise average scores
            Map<String, Map<String, Double>> genderWiseAverageScoresMap = new HashMap<>();
            for (Object[] row : genderWiseAverageScores) {
                // Extract gender and average scores from each row
                String designtion = (String) row[0];
                Double averageEh = (Double) row[1];
                Double averagePh = (Double) row[2];
                Double averageMh = (Double) row[3];
                Double averageSh = (Double) row[4];
                Double averageTotal = (Double) row[5];

                // Create a map to hold the average scores for each gender
                Map<String, Double> averageScoresMap = new HashMap<>();
                averageScoresMap.put("averageEh", averageEh);
                averageScoresMap.put("averagePh", averagePh);
                averageScoresMap.put("averageMh", averageMh);
                averageScoresMap.put("averageSh", averageSh);
                averageScoresMap.put("averageTotal", averageTotal);

                // Add gender and its corresponding average scores to the map
                genderWiseAverageScoresMap.put(designtion, averageScoresMap);
            }
            return ResponseEntity.ok(genderWiseAverageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving gender-wise average scores");
        }
    }
    @GetMapping("/average-scores-non-teaching-designation-wise")
    public ResponseEntity<?> getAverageScoresForNonTeachingUniversityRoleDesignationWise() {
        List<Object[]>genderWiseAverageScores = scoreRepository.calculateAverageScoreNonTeachingDesignationWise();

        if (genderWiseAverageScores != null) {
            // Create a map to hold the gender-wise average scores
            Map<String, Map<String, Double>> genderWiseAverageScoresMap = new HashMap<>();
            for (Object[] row : genderWiseAverageScores) {
                // Extract gender and average scores from each row
                String gender = (String) row[0];
                Double averageEh = (Double) row[1];
                Double averagePh = (Double) row[2];
                Double averageMh = (Double) row[3];
                Double averageSh = (Double) row[4];
                Double averageTotal = (Double) row[5];

                // Create a map to hold the average scores for each gender
                Map<String, Double> averageScoresMap = new HashMap<>();
                averageScoresMap.put("averageEh", averageEh);
                averageScoresMap.put("averagePh", averagePh);
                averageScoresMap.put("averageMh", averageMh);
                averageScoresMap.put("averageSh", averageSh);
                averageScoresMap.put("averageTotal", averageTotal);

                // Add gender and its corresponding average scores to the map
                genderWiseAverageScoresMap.put(gender, averageScoresMap);
            }
            return ResponseEntity.ok(genderWiseAverageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving gender-wise average scores");
        }
    }

    @GetMapping("/average-scores-non-teaching-age-group")
    public ResponseEntity<?> getAverageScoresByNonTeachingAgeGroup() {
        List<Object[]> averageScores = scoreRepository.calculateAverageScoresByNonTeachingAgeGroup();

        if (averageScores != null && !averageScores.isEmpty()) {
            Map<String, Map<String, Double>> ageGroupAverageScoresMap = new HashMap<>();
            for (Object[] row : averageScores) {
                String ageGroup = (String) row[0];
                Map<String, Double> averageScoresMap = new HashMap<>();
                averageScoresMap.put("averageEh", (Double) row[1]);
                averageScoresMap.put("averagePh", (Double) row[2]);
                averageScoresMap.put("averageMh", (Double) row[3]);
                averageScoresMap.put("averageSh", (Double) row[4]);
                averageScoresMap.put("averageTotal", (Double) row[5]);
                ageGroupAverageScoresMap.put(ageGroup, averageScoresMap);
            }
            return ResponseEntity.ok(ageGroupAverageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error retrieving average scores by age group");
        }
    }

    //office staff
    @GetMapping("/average-scores-office-staff")
    public ResponseEntity<?> getAverageScoresForOfficeStaffUniversityRole() {
        List<Object[]> averageScores = scoreRepository.findAverageScoresForOfficeStaffUniversityRole();

        if (averageScores != null && !averageScores.isEmpty()) {
            Object[] firstRow = averageScores.get(0);
            Map<String, Double> averageScoresMap = new HashMap<>();
            averageScoresMap.put("averageEh", (Double) firstRow[0]);
            averageScoresMap.put("averagePh", (Double) firstRow[1]);
            averageScoresMap.put("averageMh", (Double) firstRow[2]);
            averageScoresMap.put("averageSh", (Double) firstRow[3]);
            averageScoresMap.put("averageTotal", (Double) firstRow[4]);

            return ResponseEntity.ok(averageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving average scores for teaching university role");
        }
    }
    @GetMapping("/average-scores-office-staff-gender-wise")
    public ResponseEntity<?> getAverageScoresForOfficeStaffUniversityRoleGenderWise() {
        List<Object[]>genderWiseAverageScores = scoreRepository.calculateAverageScoreOfficeStaffGenderWise();

        if (genderWiseAverageScores != null) {
            // Create a map to hold the gender-wise average scores
            Map<String, Map<String, Double>> genderWiseAverageScoresMap = new HashMap<>();
            for (Object[] row : genderWiseAverageScores) {
                // Extract gender and average scores from each row
                String designtion = (String) row[0];
                Double averageEh = (Double) row[1];
                Double averagePh = (Double) row[2];
                Double averageMh = (Double) row[3];
                Double averageSh = (Double) row[4];
                Double averageTotal = (Double) row[5];

                // Create a map to hold the average scores for each gender
                Map<String, Double> averageScoresMap = new HashMap<>();
                averageScoresMap.put("averageEh", averageEh);
                averageScoresMap.put("averagePh", averagePh);
                averageScoresMap.put("averageMh", averageMh);
                averageScoresMap.put("averageSh", averageSh);
                averageScoresMap.put("averageTotal", averageTotal);

                // Add gender and its corresponding average scores to the map
                genderWiseAverageScoresMap.put(designtion, averageScoresMap);
            }
            return ResponseEntity.ok(genderWiseAverageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving gender-wise average scores");
        }
    }
    @GetMapping("/average-scores-office-staff-age-group")
    public ResponseEntity<?> getAverageScoresByOfficeStaffAgeGroup() {
        List<Object[]> averageScores = scoreRepository.calculateAverageScoresByOfficeStaffAgeGroup();

        if (averageScores != null && !averageScores.isEmpty()) {
            Map<String, Map<String, Double>> ageGroupAverageScoresMap = new HashMap<>();
            for (Object[] row : averageScores) {
                String ageGroup = (String) row[0];
                Map<String, Double> averageScoresMap = new HashMap<>();
                averageScoresMap.put("averageEh", (Double) row[1]);
                averageScoresMap.put("averagePh", (Double) row[2]);
                averageScoresMap.put("averageMh", (Double) row[3]);
                averageScoresMap.put("averageSh", (Double) row[4]);
                averageScoresMap.put("averageTotal", (Double) row[5]);
                ageGroupAverageScoresMap.put(ageGroup, averageScoresMap);
            }
            return ResponseEntity.ok(ageGroupAverageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error retrieving average scores by age group");
        }
    }

    //student
    @GetMapping("/average-student-scores")
    public ResponseEntity<?> getAverageStudentScores() {
        List<Object[]> teacherAverageScores = scoreRepository.calculateStudentAverageScores();

        // Check if the result is not null
        if (teacherAverageScores != null && !teacherAverageScores.isEmpty()) {
            Double averageEh = (Double) teacherAverageScores.get(0)[0];
            Double averagePh = (Double) teacherAverageScores.get(0)[1];
            Double averageMh = (Double) teacherAverageScores.get(0)[2];
            Double averageSh = (Double) teacherAverageScores.get(0)[3];
            Double averageTotal = (Double) teacherAverageScores.get(0)[4];

            // Create a map to hold the average scores for teachers
            Map<String, Double> averageScoresMap = new HashMap<>();
            averageScoresMap.put("averageEh", averageEh);
            averageScoresMap.put("averagePh", averagePh);
            averageScoresMap.put("averageMh", averageMh);
            averageScoresMap.put("averageSh", averageSh);
            averageScoresMap.put("averageTotal", averageTotal);

            return ResponseEntity.ok(averageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving average teacher scores");
        }
    }
    @GetMapping("/student-gender-wise-average-scores")
    public ResponseEntity<?> getStudentGenderWiseAverageScores() {
        List<Object[]> genderWiseAverageScores = scoreRepository.calculateStudentAverageScoreByGender();

        // Check if the result is not null
        if (genderWiseAverageScores != null) {
            // Create a map to hold the gender-wise average scores
            Map<String, Map<String, Double>> genderWiseAverageScoresMap = new HashMap<>();
            for (Object[] row : genderWiseAverageScores) {
                // Extract gender and average scores from each row
                String gender = (String) row[0];
                Double averageEh = (Double) row[1];
                Double averagePh = (Double) row[2];
                Double averageMh = (Double) row[3];
                Double averageSh = (Double) row[4];
                Double averageTotal = (Double) row[5];

                // Create a map to hold the average scores for each gender
                Map<String, Double> averageScoresMap = new HashMap<>();
                averageScoresMap.put("averageEh", averageEh);
                averageScoresMap.put("averagePh", averagePh);
                averageScoresMap.put("averageMh", averageMh);
                averageScoresMap.put("averageSh", averageSh);
                averageScoresMap.put("averageTotal", averageTotal);

                // Add gender and its corresponding average scores to the map
                genderWiseAverageScoresMap.put(gender, averageScoresMap);
            }
            return ResponseEntity.ok(genderWiseAverageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving gender-wise average scores");
        }
    }
    @GetMapping("/student-status-wise-average-scores")
    public ResponseEntity<?> getStudentStatusWiseAverageScores() {
        List<Object[]> genderWiseAverageScores = scoreRepository.calculateStudentAverageScoreByStatus();

        // Check if the result is not null
        if (genderWiseAverageScores != null) {
            // Create a map to hold the gender-wise average scores
            Map<String, Map<String, Double>> genderWiseAverageScoresMap = new HashMap<>();
            for (Object[] row : genderWiseAverageScores) {
                // Extract gender and average scores from each row
                String gender = (String) row[0];
                Double averageEh = (Double) row[1];
                Double averagePh = (Double) row[2];
                Double averageMh = (Double) row[3];
                Double averageSh = (Double) row[4];
                Double averageTotal = (Double) row[5];

                // Create a map to hold the average scores for each gender
                Map<String, Double> averageScoresMap = new HashMap<>();
                averageScoresMap.put("averageEh", averageEh);
                averageScoresMap.put("averagePh", averagePh);
                averageScoresMap.put("averageMh", averageMh);
                averageScoresMap.put("averageSh", averageSh);
                averageScoresMap.put("averageTotal", averageTotal);

                // Add gender and its corresponding average scores to the map
                genderWiseAverageScoresMap.put(gender, averageScoresMap);
            }
            return ResponseEntity.ok(genderWiseAverageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving gender-wise average scores");
        }
    }
    @GetMapping("/student-semester-wise-average-scores")
    public ResponseEntity<?> getStudentSemesterWiseAverageScores() {
        List<Object[]> genderWiseAverageScores = scoreRepository.calculateStudentAverageScoreBySemester();

        // Check if the result is not null
        if (genderWiseAverageScores != null) {
            // Create a map to hold the gender-wise average scores
            Map<String, Map<String, Double>> genderWiseAverageScoresMap = new HashMap<>();
            for (Object[] row : genderWiseAverageScores) {
                // Extract gender and average scores from each row
                String gender = (String) row[0];
                Double averageEh = (Double) row[1];
                Double averagePh = (Double) row[2];
                Double averageMh = (Double) row[3];
                Double averageSh = (Double) row[4];
                Double averageTotal = (Double) row[5];

                // Create a map to hold the average scores for each gender
                Map<String, Double> averageScoresMap = new HashMap<>();
                averageScoresMap.put("averageEh", averageEh);
                averageScoresMap.put("averagePh", averagePh);
                averageScoresMap.put("averageMh", averageMh);
                averageScoresMap.put("averageSh", averageSh);
                averageScoresMap.put("averageTotal", averageTotal);

                // Add gender and its corresponding average scores to the map
                genderWiseAverageScoresMap.put(gender, averageScoresMap);
            }
            return ResponseEntity.ok(genderWiseAverageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving gender-wise average scores");
        }
    }

    //post-graduate
    @GetMapping("/average-student-post-graduate-scores")
    public ResponseEntity<?> getAverageStudentPostGraduateScores() {
        List<Object[]> teacherAverageScores = scoreRepository.findAverageScoresForPostGraduateStatus();

        // Check if the result is not null
        if (teacherAverageScores != null && !teacherAverageScores.isEmpty()) {
            Double averageEh = (Double) teacherAverageScores.get(0)[0];
            Double averagePh = (Double) teacherAverageScores.get(0)[1];
            Double averageMh = (Double) teacherAverageScores.get(0)[2];
            Double averageSh = (Double) teacherAverageScores.get(0)[3];
            Double averageTotal = (Double) teacherAverageScores.get(0)[4];

            // Create a map to hold the average scores for teachers
            Map<String, Double> averageScoresMap = new HashMap<>();
            averageScoresMap.put("averageEh", averageEh);
            averageScoresMap.put("averagePh", averagePh);
            averageScoresMap.put("averageMh", averageMh);
            averageScoresMap.put("averageSh", averageSh);
            averageScoresMap.put("averageTotal", averageTotal);

            return ResponseEntity.ok(averageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving average teacher scores");
        }
    }
    @GetMapping("/student-post-graduate-gender-wise-average-scores")
    public ResponseEntity<?> getStudentPostGraduateGenderWiseAverageScores() {
        List<Object[]> genderWiseAverageScores = scoreRepository.calculateAverageScorePostGraduateGenderWise();

        // Check if the result is not null
        if (genderWiseAverageScores != null) {
            // Create a map to hold the gender-wise average scores
            Map<String, Map<String, Double>> genderWiseAverageScoresMap = new HashMap<>();
            for (Object[] row : genderWiseAverageScores) {
                // Extract gender and average scores from each row
                String gender = (String) row[0];
                Double averageEh = (Double) row[1];
                Double averagePh = (Double) row[2];
                Double averageMh = (Double) row[3];
                Double averageSh = (Double) row[4];
                Double averageTotal = (Double) row[5];

                // Create a map to hold the average scores for each gender
                Map<String, Double> averageScoresMap = new HashMap<>();
                averageScoresMap.put("averageEh", averageEh);
                averageScoresMap.put("averagePh", averagePh);
                averageScoresMap.put("averageMh", averageMh);
                averageScoresMap.put("averageSh", averageSh);
                averageScoresMap.put("averageTotal", averageTotal);

                // Add gender and its corresponding average scores to the map
                genderWiseAverageScoresMap.put(gender, averageScoresMap);
            }
            return ResponseEntity.ok(genderWiseAverageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving gender-wise average scores");
        }
    }
    @GetMapping("/student-post-graduate-degree-wise-average-scores")
    public ResponseEntity<?> getStudentPostGraduateDegreeWiseAverageScores() {
        List<Object[]> degreeWiseAverageScores = scoreRepository.calculateAverageScorePostGraduateDegreeWise();

        if (degreeWiseAverageScores != null) {
            Map<String, Map<String, Double>> degreeWiseAverageScoresMap = new HashMap<>();
            for (Object[] row : degreeWiseAverageScores) {
                String degree = (String) row[0];
                Double averageEh = (Double) row[1];
                Double averagePh = (Double) row[2];
                Double averageMh = (Double) row[3];
                Double averageSh = (Double) row[4];
                Double averageTotal = (Double) row[5];

                Map<String, Double> averageScoresMap = new HashMap<>();
                averageScoresMap.put("averageEh", averageEh);
                averageScoresMap.put("averagePh", averagePh);
                averageScoresMap.put("averageMh", averageMh);
                averageScoresMap.put("averageSh", averageSh);
                averageScoresMap.put("averageTotal", averageTotal);

                degreeWiseAverageScoresMap.put(degree, averageScoresMap);
            }
            return ResponseEntity.ok(degreeWiseAverageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving degree-wise average scores");
        }
    }
    @GetMapping("/student-post-graduate-semester-wise-average-scores")
    public ResponseEntity<?> getStudentPostGraduateSemesterWiseAverageScores() {
        try {
            List<Object[]> semesterWiseAverageScores = scoreRepository.calculateAverageScorePostGraduateSemesterWise();

            if (semesterWiseAverageScores != null && !semesterWiseAverageScores.isEmpty()) {
                Map<String, Map<String, Double>> semesterWiseAverageScoresMap = new HashMap<>();
                for (Object[] row : semesterWiseAverageScores) {
                    if (row[0] != null) {
                        // Cast the semester to Integer and convert to String
                        Integer semesterInt = (Integer) row[0];
                        String semester = semesterInt.toString();

                        Double averageEh = (row[1] != null) ? ((Number) row[1]).doubleValue() : 0.0;
                        Double averagePh = (row[2] != null) ? ((Number) row[2]).doubleValue() : 0.0;
                        Double averageMh = (row[3] != null) ? ((Number) row[3]).doubleValue() : 0.0;
                        Double averageSh = (row[4] != null) ? ((Number) row[4]).doubleValue() : 0.0;
                        Double averageTotal = (row[5] != null) ? ((Number) row[5]).doubleValue() : 0.0;

                        Map<String, Double> averageScoresMap = new HashMap<>();
                        averageScoresMap.put("averageEh", averageEh);
                        averageScoresMap.put("averagePh", averagePh);
                        averageScoresMap.put("averageMh", averageMh);
                        averageScoresMap.put("averageSh", averageSh);
                        averageScoresMap.put("averageTotal", averageTotal);

                        semesterWiseAverageScoresMap.put(semester, averageScoresMap);
                    }
                }
                return ResponseEntity.ok(semesterWiseAverageScoresMap);
            } else {
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No data found for semester-wise average scores");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving semester-wise average scores: " + e.getMessage());
        }
    }

    //undergraduate
    @GetMapping("/average-student-under-graduate-scores")
    public ResponseEntity<?> getAverageStudentUnderGraduateScores() {
        List<Object[]> teacherAverageScores = scoreRepository.findAverageScoresForUnderGraduateStatus();

        // Check if the result is not null
        if (teacherAverageScores != null && !teacherAverageScores.isEmpty()) {
            Double averageEh = (Double) teacherAverageScores.get(0)[0];
            Double averagePh = (Double) teacherAverageScores.get(0)[1];
            Double averageMh = (Double) teacherAverageScores.get(0)[2];
            Double averageSh = (Double) teacherAverageScores.get(0)[3];
            Double averageTotal = (Double) teacherAverageScores.get(0)[4];

            // Create a map to hold the average scores for teachers
            Map<String, Double> averageScoresMap = new HashMap<>();
            averageScoresMap.put("averageEh", averageEh);
            averageScoresMap.put("averagePh", averagePh);
            averageScoresMap.put("averageMh", averageMh);
            averageScoresMap.put("averageSh", averageSh);
            averageScoresMap.put("averageTotal", averageTotal);

            return ResponseEntity.ok(averageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving average teacher scores");
        }
    }
    @GetMapping("/student-under-graduate-gender-wise-average-scores")
    public ResponseEntity<?> getStudentGraduateGenderWiseAverageScores() {
        List<Object[]> genderWiseAverageScores = scoreRepository.calculateAverageScoreUnderGraduateGenderWise();

        // Check if the result is not null
        if (genderWiseAverageScores != null) {
            // Create a map to hold the gender-wise average scores
            Map<String, Map<String, Double>> genderWiseAverageScoresMap = new HashMap<>();
            for (Object[] row : genderWiseAverageScores) {
                // Extract gender and average scores from each row
                String gender = (String) row[0];
                Double averageEh = (Double) row[1];
                Double averagePh = (Double) row[2];
                Double averageMh = (Double) row[3];
                Double averageSh = (Double) row[4];
                Double averageTotal = (Double) row[5];

                // Create a map to hold the average scores for each gender
                Map<String, Double> averageScoresMap = new HashMap<>();
                averageScoresMap.put("averageEh", averageEh);
                averageScoresMap.put("averagePh", averagePh);
                averageScoresMap.put("averageMh", averageMh);
                averageScoresMap.put("averageSh", averageSh);
                averageScoresMap.put("averageTotal", averageTotal);

                // Add gender and its corresponding average scores to the map
                genderWiseAverageScoresMap.put(gender, averageScoresMap);
            }
            return ResponseEntity.ok(genderWiseAverageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving gender-wise average scores");
        }
    }
    @GetMapping("/student-under-graduate-degree-wise-average-scores")
    public ResponseEntity<?> getStudentUnderGraduateDegreeWiseAverageScores() {
        List<Object[]> degreeWiseAverageScores = scoreRepository.calculateAverageScoreUnderGraduateDegreeWise();

        if (degreeWiseAverageScores != null) {
            Map<String, Map<String, Double>> degreeWiseAverageScoresMap = new HashMap<>();
            for (Object[] row : degreeWiseAverageScores) {
                String degree = (String) row[0];
                Double averageEh = (Double) row[1];
                Double averagePh = (Double) row[2];
                Double averageMh = (Double) row[3];
                Double averageSh = (Double) row[4];
                Double averageTotal = (Double) row[5];

                Map<String, Double> averageScoresMap = new HashMap<>();
                averageScoresMap.put("averageEh", averageEh);
                averageScoresMap.put("averagePh", averagePh);
                averageScoresMap.put("averageMh", averageMh);
                averageScoresMap.put("averageSh", averageSh);
                averageScoresMap.put("averageTotal", averageTotal);

                degreeWiseAverageScoresMap.put(degree, averageScoresMap);
            }
            return ResponseEntity.ok(degreeWiseAverageScoresMap);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving degree-wise average scores");
        }
    }
    @GetMapping("/student-under-graduate-semester-wise-average-scores")
    public ResponseEntity<?> getStudentUnderGraduateSemesterWiseAverageScores() {
        try {
            List<Object[]> semesterWiseAverageScores = scoreRepository.calculateAverageScoreUnderGraduateSemesterWise();

            if (semesterWiseAverageScores != null && !semesterWiseAverageScores.isEmpty()) {
                Map<String, Map<String, Double>> semesterWiseAverageScoresMap = new HashMap<>();
                for (Object[] row : semesterWiseAverageScores) {
                    if (row[0] != null) {
                        // Cast the semester to Integer and convert to String
                        Integer semesterInt = (Integer) row[0];
                        String semester = semesterInt.toString();

                        Double averageEh = (row[1] != null) ? ((Number) row[1]).doubleValue() : 0.0;
                        Double averagePh = (row[2] != null) ? ((Number) row[2]).doubleValue() : 0.0;
                        Double averageMh = (row[3] != null) ? ((Number) row[3]).doubleValue() : 0.0;
                        Double averageSh = (row[4] != null) ? ((Number) row[4]).doubleValue() : 0.0;
                        Double averageTotal = (row[5] != null) ? ((Number) row[5]).doubleValue() : 0.0;

                        Map<String, Double> averageScoresMap = new HashMap<>();
                        averageScoresMap.put("averageEh", averageEh);
                        averageScoresMap.put("averagePh", averagePh);
                        averageScoresMap.put("averageMh", averageMh);
                        averageScoresMap.put("averageSh", averageSh);
                        averageScoresMap.put("averageTotal", averageTotal);

                        semesterWiseAverageScoresMap.put(semester, averageScoresMap);
                    }
                }
                return ResponseEntity.ok(semesterWiseAverageScoresMap);
            } else {
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No data found for semester-wise average scores");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving semester-wise average scores: " + e.getMessage());
        }
    }
    @GetMapping("/student-recent-score")
    public ResponseEntity<?> getRecentScoreByEmail(@RequestParam String email) {
        try {
            List<Object[]> recentScores = scoreRepository.findRecentScoreByEmail(email);

            if (recentScores != null && !recentScores.isEmpty()) {
                Object[] recentScore = recentScores.get(0);

                // Create a map to hold the recent score details
                Map<String, Object> scoreDetails = new HashMap<>();
                scoreDetails.put("email", recentScore[0]);
                scoreDetails.put("eh", recentScore[1]);
                scoreDetails.put("ph", recentScore[2]);
                scoreDetails.put("mh", recentScore[3]);
                scoreDetails.put("sh", recentScore[4]);
                scoreDetails.put("total", recentScore[5]);
                scoreDetails.put("time", recentScore[6]);

                return ResponseEntity.ok(scoreDetails);
            } else {
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No recent score found for the given email");
            }
        } catch (Exception e) {
            e.printStackTrace(); // Print the stack trace for debugging
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving recent score: " + e.getMessage());
        }
    }

}


