package com.example.qola.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;

import java.util.Date;

@Entity
public class Score {
    @Id
    @GeneratedValue
    private Long Id;
    private String type;
    private String email;
    private Float ph;
    private Float mh;
    private Float sh;
    private Float eh;
    private Float total;
    private Date time;

    // Getters and setters
    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Float getPh() {
        return ph;
    }

    public void setPh(Float ph) {
        this.ph = ph;
    }

    public Float getMh() {
        return mh;
    }

    public void setMh(Float mh) {
        this.mh = mh;
    }

    public Float getSh() {
        return sh;
    }

    public void setSh(Float sh) {
        this.sh = sh;
    }

    public Float getEh() {
        return eh;
    }

    public void setEh(Float eh) {
        this.eh = eh;
    }

    public Float getTotal() {
        return total;
    }

    public void setTotal(Float total) {
        this.total = total;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    @PrePersist
    protected void onCreate() {
        this.time = new Date();
    }
}
