package com.example.qola.controller;

import com.example.qola.model.Teacher;
import com.example.qola.repository.TeacherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Optional;

@RestController
@CrossOrigin
public class TeacherController {

    private static final Logger logger = LoggerFactory.getLogger(TeacherController.class);

    @Autowired
    private TeacherRepository teacherRepository;

    @PostMapping("/teacher/register")
    public ResponseEntity<String> newTeacher(@RequestBody Teacher newTeacher) {
        try {
            logger.info("Attempting to register a new teacher with email: {}", newTeacher.getEmail());

            if (teacherRepository.existsByEmail(newTeacher.getEmail())) {
                logger.warn("Registration attempt failed: User with email {} already exists", newTeacher.getEmail());
                return ResponseEntity.status(HttpStatus.CONFLICT).body("User already exists");
            }

            teacherRepository.save(newTeacher);
            logger.info("Teacher with email {} registered successfully", newTeacher.getEmail());
            return ResponseEntity.status(HttpStatus.CREATED).body("User created successfully");

        } catch (Exception e) {
            logger.error("Error during teacher registration", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal Server Error");
        }
    }

    @PostMapping("/teacher/login")
    public ResponseEntity<String> login(@RequestBody Teacher loginTeacher) {
        try {
            logger.info("Login attempt for teacher with email: {}", loginTeacher.getEmail());

            Optional<Teacher> existingUser = teacherRepository.findByEmail(loginTeacher.getEmail());
            if (existingUser.isPresent()) {
                if (existingUser.get().getPassword().equals(loginTeacher.getPassword())) {
                    AuthContext.setAuthenticatedEmail(loginTeacher.getEmail());
                    AuthContext.setUserType("teacher");
                    logger.info("Teacher with email {} logged in successfully", loginTeacher.getEmail());
                    return ResponseEntity.ok("Login successful");
                } else {
                    logger.warn("Login attempt failed: Incorrect password for email {}", loginTeacher.getEmail());
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Incorrect password");
                }
            } else {
                logger.warn("Login attempt failed: User with email {} not found", loginTeacher.getEmail());
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
            }
        } catch (Exception e) {
            logger.error("Error during teacher login", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal Server Error");
        }
    }

    @GetMapping("/teacher/displayteacher")
    public ResponseEntity<?> displayTeacher() {
        try {
            String email = AuthContext.getAuthenticatedEmail();
            logger.info("Fetching details for teacher with email: {}", email);

            Optional<Teacher> teacher = teacherRepository.findByEmail(email);
            if (teacher.isPresent()) {
                logger.info("Teacher details found for email: {}", email);
                return ResponseEntity.ok(teacher.get());
            } else {
                logger.warn("Teacher details not found for email: {}", email);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Teacher not found");
            }
        } catch (Exception e) {
            logger.error("Error fetching teacher details", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal Server Error");
        }
    }

    @PutMapping("/teacher/update")
    public ResponseEntity<String> updateTeacher(@RequestBody Teacher updatedTeacher) {
        try {
            String email = AuthContext.getAuthenticatedEmail();
            logger.info("Updating details for teacher with email: {}", email);

            Optional<Teacher> existingTeacher = teacherRepository.findByEmail(email);
            if (existingTeacher.isPresent()) {
                Teacher teacher = existingTeacher.get();
                teacher.setName(updatedTeacher.getName());
                teacher.setEmp_id(updatedTeacher.getEmp_id());
                teacher.setPassword(updatedTeacher.getPassword());
                teacher.setDob(updatedTeacher.getDob());
                teacher.setAge(updatedTeacher.getAge());
                teacher.setQualification(updatedTeacher.getQualification());
                teacher.setExperience(updatedTeacher.getExperience());
                teacher.setUniversity_role(updatedTeacher.getUniversity_role());
                teacher.setDesignation(updatedTeacher.getDesignation());
                teacher.setGender(updatedTeacher.getGender());

                teacherRepository.save(teacher);
                logger.info("Teacher details updated successfully for email: {}", email);
                return ResponseEntity.ok("Teacher information updated successfully");
            } else {
                logger.warn("Update attempt failed: Teacher not found for email: {}", email);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Teacher not found");
            }
        } catch (Exception e) {
            logger.error("Error updating teacher details", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Internal Server Error");
        }
    }
}
