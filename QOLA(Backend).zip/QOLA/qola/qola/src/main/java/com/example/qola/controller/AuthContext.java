package com.example.qola.controller;

public class AuthContext {
    private static String authenticatedEmail = "";
    private static String userType = "";

    public static String getAuthenticatedEmail() {
        return authenticatedEmail;
    }

    public static void setAuthenticatedEmail(String email) {
        authenticatedEmail = email;
    }

    public static String getUserType() {
        return userType;
    }

    public static void setUserType(String type) {
        userType = type;
    }
}
