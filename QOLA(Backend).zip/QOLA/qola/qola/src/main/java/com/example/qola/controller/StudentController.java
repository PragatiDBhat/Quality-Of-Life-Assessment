package com.example.qola.controller;

import com.example.qola.model.Student;
import com.example.qola.repository.StudentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@CrossOrigin
public class StudentController {

    private static final Logger logger = LoggerFactory.getLogger(StudentController.class);

    @Autowired
    private StudentRepository studentRepository;

    @PostMapping("/student/register")
    public ResponseEntity<String> newStudent(@RequestBody Student newStudent) {
        try {
            Optional<Student> existingUser = studentRepository.findByEmail(newStudent.getEmail());
            if (existingUser.isPresent()) {
                return ResponseEntity.status(HttpStatus.CONFLICT).body("User already exists");
            }
            studentRepository.save(newStudent);
            logger.info("Student registered successfully: {}", newStudent.getEmail());
            return ResponseEntity.status(HttpStatus.CREATED).body("User created successfully");
        } catch (Exception e) {
            logger.error("Error registering student: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error registering student");
        }
    }

    @PostMapping("/student/login")
    public ResponseEntity<String> login(@RequestBody Student loginStudent) {
        try {
            Optional<Student> existingUser = studentRepository.findByEmail(loginStudent.getEmail());
            if (existingUser.isPresent()) {
                if (existingUser.get().getPassword().equals(loginStudent.getPassword())) {
                    // Set authenticated user email and type (example purpose only)
                    AuthContext.setAuthenticatedEmail(loginStudent.getEmail());
                    AuthContext.setUserType("student");
                    logger.info("Student logged in successfully: {}", loginStudent.getEmail());
                    return ResponseEntity.ok("Login successful");
                } else {
                    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Incorrect password");
                }
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
            }
        } catch (Exception e) {
            logger.error("Error during student login: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error during student login");
        }
    }

    @GetMapping("/student/displaystudent")
    public ResponseEntity<?> displayStudent() {
        try {
            String email = AuthContext.getAuthenticatedEmail();
            Optional<Student> student = studentRepository.findByEmail(email);
            if (student.isPresent()) {
                return ResponseEntity.ok(student.get());
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Student not found");
            }
        } catch (Exception e) {
            logger.error("Error displaying student information: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error displaying student information");
        }
    }

    @PutMapping("/student/update")
    public ResponseEntity<String> updateStudent(@RequestBody Student updatedStudent) {
        try {
            String email = AuthContext.getAuthenticatedEmail();
            Optional<Student> existingStudent = studentRepository.findByEmail(email);
            if (existingStudent.isPresent()) {
                Student student = existingStudent.get();
                student.setName(updatedStudent.getName());
                student.setUsn(updatedStudent.getUsn());
                student.setPassword(updatedStudent.getPassword());
                student.setDob(updatedStudent.getDob());
                student.setAge(updatedStudent.getAge());
                student.setStatus(updatedStudent.getStatus());
                student.setDegree(updatedStudent.getDegree());
                student.setSemester(updatedStudent.getSemester());
                student.setGender(updatedStudent.getGender());
                studentRepository.save(student);
                logger.info("Student information updated successfully: {}", email);
                return ResponseEntity.ok("Student information updated successfully");
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Student not found");
            }
        } catch (Exception e) {
            logger.error("Error updating student information: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error updating student information");
        }
    }

    @PostMapping("/logout")
    public ResponseEntity<String> logout() {
        try {
            AuthContext.setAuthenticatedEmail(""); // Clear authenticated email
            AuthContext.setUserType(""); // Clear user type
            return ResponseEntity.ok("Logout successful");
        } catch (Exception e) {
            logger.error("Error during logout: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error during logout");
        }
    }
}
