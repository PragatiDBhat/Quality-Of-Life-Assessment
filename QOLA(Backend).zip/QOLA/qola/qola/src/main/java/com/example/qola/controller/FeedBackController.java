package com.example.qola.controller;

import com.example.qola.model.FeedBack;
import com.example.qola.repository.FeedbackRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
public class FeedBackController {

    @Autowired
    private FeedbackRepository feedBackRepository;

    @PostMapping("/feedback")
    public ResponseEntity<String> saveFeedback(@RequestBody FeedBack feedBack) {
        feedBackRepository.save(feedBack);
        return ResponseEntity.status(HttpStatus.CREATED).body("Feedback saved successfully");
    }
}
